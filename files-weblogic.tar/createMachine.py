if __name__ == '__main__':
    from wlstModule import *

adminServerName="AdminServer"
adminServerListenAddress=sys.argv[1]
adminServerListenPort=sys.argv[2]
userName=sys.argv[3]
passWord=sys.argv[4]
machineName=sys.argv[5]
nmListenPort=sys.argv[6]
URL="t3://" + adminServerListenAddress + ":" + adminServerListenPort

hideDisplay()
hideDumpStack("true")
try:
  connect(userName, passWord, URL)
except WLSTException:
  print 'No se puede conectar a ' + URL
hideDumpStack("false")
 
#start up an edit session
edit()
startEdit()
#change to the root
cd('/')
 
getMBean("/Machines/" + machineName)

#create a unix machine with what ever name suits
cmo.createMachine(machineName)
print 'Create machine result: ' + str(machineName)

cd('/Machines/'+machineName+'/NodeManager/'+machineName)
#set the nodemanager settings, again that match the settings set up in 
#the create domain script
cmo.setNMType('ssl')  
cmo.setListenAddress(adminServerListenAddress)
cmo.setListenPort(int(nmListenPort))
 
#save and activate the changes
save()
activate(block="true")
 
print 'Done'