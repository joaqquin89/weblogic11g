#!/bin/sh
#Nombre:      entrypoint.sh
#Descripcion: Up the WL Service
#Fecha:       19/01/2018
#By:          J.J.CH.

export HOME=/u01/home/app
export DOMAIN_PATH=$HOME/domains
export DOMAIN_NAME=fcCLdomain
export WL_HOME=$HOME/Oracle/wlserver_10.3

#Encender el nodemanager
nohup $WL_HOME/server/bin/startNodeManager.sh &> $HOME/oracle/nodemanager.out &
#ENCENDER DOMINIO
nohup ${DOMAIN_PATH}/${DOMAIN_NAME}/startWebLogic.sh &> $HOME/oracle/domain.out &