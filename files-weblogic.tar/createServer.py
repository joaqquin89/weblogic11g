from weblogic.descriptor import BeanAlreadyExistsException
from java.lang.reflect import UndeclaredThrowableException
from java.lang import UnsupportedOperationException

adminbeanName="AdminServer"
adminServerListenAddress=sys.argv[1]
adminServerListenPort=sys.argv[2]
userName=sys.argv[3]
passWord=sys.argv[4]
beanName=sys.argv[5]
listenPort=sys.argv[6]
sslListenPort=sys.argv[7]
machineName=sys.argv[8]
domainPath=sys.argv[9]
domName=sys.argv[10]
utilsHome=sys.argv[11]
domHome=domainPath + "/" + domName
platformHome=utilsHome + "/wlserver_10.3"
serverHome=platformHome + "/server"
javaHome=sys.argv[12]
pathCerts=sys.argv[13]
aliasCerts=sys.argv[14]
passCerts=sys.argv[15]

try:
  additionalArguments=sys.argv[12]
except:
  additionalArguments=""

def initConfigToScriptRun():
  hideDisplay()
  hideDumpStack("true")
  try:
    URL="t3://"+adminServerListenAddress+":"+adminServerListenPort
    connect(userName, passWord, URL)
  except WLSTException:
    print 'No se puede conectar a ' + URL
  hideDumpStack("false")

def startTransaction():
  edit()
  startEdit()

def endTransaction():
  startEdit()
  save() 
  try:
    activate(20000,block="true")
  except:
    undo("true","y")
    stopEdit("y")
    dumpStack() 

from javax.management import InstanceAlreadyExistsException
from java.lang import Exception
from jarray import array

def createServer():
  cd("/")
  try:
    print "Creando Server... "
    theBean = cmo.lookupServer(beanName)
    if theBean == None:
      cmo.createServer(beanName)
  except java.lang.UnsupportedOperationException, usoe:
    pass
  except weblogic.descriptor.BeanAlreadyExistsException,bae:
    pass
  except java.lang.reflect.UndeclaredThrowableException,udt:
    pass

def setAttributesForServer():
  cd("/Servers/" + beanName)
  print "Configurando atributos del Server"
  set("ListenPort", listenPort)
  set("JavaCompiler", "javac")
  set("ListenPortEnabled", "true")
  set("ListenAddress", adminServerListenAddress)
  set("ClientCertProxyEnabled", "false")
  cmo.setMachine(getMBean("/Machines/" + machineName))
  #cd('/Servers/' + beanName + '/SSL/' + beanName)
  #set("ListenPort", sslListenPort)
  cd('/Servers/'+beanName)
  cmo.setCustomIdentityKeyStoreFileName(pathCerts+'/certs/identity_test.jks')
  set('CustomIdentityKeyStorePassPhrase', passCerts)
  cmo.setCustomTrustKeyStoreFileName(pathCerts+'/certs/trust_test.jks')
  set('CustomTrustKeyStorePassPhrase', passCerts)
  cmo.setKeyStores('CustomIdentityAndCustomTrust')
  cmo.setCustomIdentityKeyStoreType('JKS')
  cmo.setCustomTrustKeyStoreType('JKS')
  cd('/Servers/'+beanName+'/SSL/'+beanName)
  cmo.setServerPrivateKeyAlias(aliasCerts)
  set('ServerPrivateKeyPassPhrase', passCerts)
  cd('/Servers/'+beanName+'/SSL/'+beanName)
  set("ListenPort", sslListenPort)
  set('Enabled', 'True')

def setAttributesServerStart():
  try:
    cd("/Servers/" + beanName + "/OverloadProtection/" + beanName + "/ServerFailureTrigger/" + beanName)
  except:
    cd("/Servers/" + beanName + "/OverloadProtection/" + beanName)
    cmo.createServerFailureTrigger()
    cd("/Servers/" + beanName + "/OverloadProtection/" + beanName + "/ServerFailureTrigger/" + beanName)
  cd("/Servers/" + beanName + "/ServerStart/" + beanName)
  print "Configurando atributos de inicio del Server"
  set("JavaHome", javaHome)
  set("Arguments", "-jrockit -Xms2048m -Xmx2048m -Xverify:none -da -Dplatform.home=" + platformHome + 
                                                               " -Dwls.home=" + serverHome + 
                                                               " -Dweblogic.home=" + serverHome + 
                                                               " -Dweblogic.management.discover=false" +
                                                               " -Dweblogic.management.server=http://" + adminServerListenAddress + ":" + adminServerListenPort + 
                                                               " -Dwlw.iterativeDev=false" +
                                                               " -Dwlw.testConsole=false" +
                                                               " -Dwlw.logErrorsToConsole=true" +
                                                               " -Dweblogic.Name=" + beanName
                                                               )
  set("Username", userName)
  set("Password", passWord)
  set("JavaVendor", "BEA")
  set("SecurityPolicyFile", serverHome + "/lib/weblogic.policy")
  set("RootDirectory", domHome)
  set("ClassPath", platformHome + "/server/lib/weblogic_sp.jar:" +
                   platformHome + "/server/lib/weblogic.jar")

initConfigToScriptRun()
startTransaction()
createServer()
setAttributesForServer()
setAttributesServerStart()
endTransaction()
disconnect()
